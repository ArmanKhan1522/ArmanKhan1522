# Custom Classes in Python
# Rectangle Class Implementation


class Rectangle:
    def __init__(self, length, width):
        self.length = length
        self.width = width

    def show_data(self):
        print(f"Length: {self.length}, Width: {self.width}")


rect = Rectangle(5, 10)
rect.show_data()
