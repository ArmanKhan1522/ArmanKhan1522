"""Are Django signals executed synchronously or asynchronously by default"""

from django.dispatch import Signal, receiver

# Define a signal
my_signal = Signal()


# Define a signal handler
@receiver(my_signal)
def my_handler(sender, **kwargs):
    print("Signal received!")


# Sending the signal
print("Before sending signal")
my_signal.send(sender=None)
print("After sending signal")


"""Do django signals run in the same thread as the caller"""
import threading
from django.dispatch import Signal, receiver

# Define a signal
my_signal = Signal()


# Define a signal handler
@receiver(my_signal)
def my_handler(sender, **kwargs):
    print(f"Signal received in thread: {threading.current_thread().name}")


# Sending the signal
print(f"Before sending signal in thread: {threading.current_thread().name}")
my_signal.send(sender=None)
print(f"After sending signal in thread: {threading.current_thread().name}")


"""Do Django signals run in the same database transaction as the caller"""
from django.db import transaction
from django.dispatch import Signal, receiver

# Define a signal
my_signal = Signal()


# Define a signal handler
@receiver(my_signal)
def my_handler(sender, **kwargs):
    print("Signal received!")


# Using a transaction
with transaction.atomic():
    print("Inside transaction")
    my_signal.send(sender=None)
    # If an exception occurs here, the transaction will be rolled back
